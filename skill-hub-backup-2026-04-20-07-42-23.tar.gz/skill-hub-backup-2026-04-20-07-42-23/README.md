# Skill Hub Backup

This archive is an offline backup of your Claude / Codex / universal skills,
created by Skill Hub (https://github.com/Backtthefuture/huangshu).

Layout:
  <agent>/<skill-name>/SKILL.md
  <agent>/<skill-name>/... supporting files ...
  .skillhub/manifest.json   metadata about this archive

To restore manually: copy each <agent>/<skill> directory into the matching
agent skills directory on your machine:
  - claude-code → ~/.claude/skills/
  - codex       → ~/.codex/skills/
  - universal   → ~/.agents/skills/

Or: set up Skill Hub + connect a GitHub repo, push this content there, then
use the "从 GitHub 下载" feature on your new machine.
